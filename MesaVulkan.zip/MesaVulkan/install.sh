#!/usr/bin/env bash

mkdir -p /usr/share/vulkan/icd.d
cp ./libvulkan_intel.so    /usr/share/vulkan/icd.d/libvulkan_intel.so
cp ./intel_icd.x86_64.json /usr/share/vulkan/icd.d/intel_icd.x86_64.json
cp ./20-intel.conf         /etc/X11/xorg.conf.d/20-intel.conf

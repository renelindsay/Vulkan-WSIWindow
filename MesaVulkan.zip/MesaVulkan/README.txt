This folder contains a pre-compiled Mesa Vulkan ICD driver for Intel GPU's on Ubuntu 16.04,
and was compiled from the 'https://github.com/mesa3d/mesa' repo on 28 Dec 2016.
It requires at least a 4th-gen (Haswell) Intel GPU, or newer.

To install it, run the following command from this folder:

sudo ./install_mesa_vulkan.sh

Then, run vulkaninfo, to confirm that the Vulkan ICD is found.

Be warned that the '/etc/X11/xorg.conf.d/20-intel.conf' file enables DRI3 (required for Vulkan),
which may cause rendering problems for some nvidia GPU's, particularly laptops with nvidia-prime.

For example, if Ubuntu boots to a black screen when using NVidia, 
do the following to revert to DRI2 and recover:

Press 'CTRL-ALT-F1' to open the terminal, and log in.
sudo rm /etc/X11/xorg.conf.d/20-intel.conf
sudo prime-select nvidia
sudo service lightdm restart

